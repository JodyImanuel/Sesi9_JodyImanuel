const { Builder, By, until, WebDriver, Options } = require('selenium-webdriver');
const assert = require('assert');
const chrome = require('selenium-webdriver/chrome');

describe('WEB Automation Fundamental', function () {
    let driver;

    it("Login sukses dan dapat menampilkan Dashboard", async function () {
        options = new chrome.Options()
        options.addArguments('--incognito')
        driver = await new Builder().forBrowser('chrome').build()

        await driver.get('https://www.saucedemo.com/')
        let inputUsername = await driver.findElement(By.css('[data-test="username"]'))
        let inputPassword = await driver.findElement(By.xpath('//*[@data-test="password"]'))
        let buttonLogin = await driver.findElement(By.className('submit-button btn_action'))
        await inputUsername.sendKeys('standard_user')
        await inputPassword.sendKeys('secret_sauce')
        await buttonLogin.click()

        // Assertion
        let textAppLogo = await driver.findElement(By.className('app_logo'));
        let logoText = await textAppLogo.getText();
        assert.strictEqual(logoText,'Swag Labs')

        await driver.sleep(10000)
        
        await driver.quit()
    })

    it('Filter dari Z to A', async function () {
        options = new chrome.Options()
        options.addArguments('--incognito')
        driver = await new Builder().forBrowser('chrome').build()

        await driver.get('https://www.saucedemo.com/')
        let inputUsername = await driver.findElement(By.css('[data-test="username"]'))
        let inputPassword = await driver.findElement(By.xpath('//*[@data-test="password"]'))
        let buttonLogin = await driver.findElement(By.className('submit-button btn_action'))
        await inputUsername.sendKeys('standard_user')
        await inputPassword.sendKeys('secret_sauce')
        await buttonLogin.click()

        let filterDropdown = await driver.findElement(By.className('product_sort_container'));

        await filterDropdown.findElement(By.xpath("//option[text()='Name (Z to A)']")).click();

        // Assertion
        let textAppLogo = await driver.findElement(By.className('app_logo'));
        let logoText = await textAppLogo.getText();
        assert.strictEqual(logoText,'Swag Labs')

        await driver.sleep(10000)
        
        await driver.quit()
    })
})